import React from 'react'

const Checkout = () => {
  return (
    <div>
      coming soon
    </div>
  )
}

export default Checkout
