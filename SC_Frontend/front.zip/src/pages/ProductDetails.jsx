import React from 'react'

const ProductDetails = () => {
  return (
    <div>
      coming soon
    </div>
  )
}

export default ProductDetails
