import React from 'react'

const Cart = () => {
  return (
    <div>
      coming soon
    </div>
  )
}

export default Cart
